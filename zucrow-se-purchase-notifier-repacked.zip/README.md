# Zucrow SE – Purchase Notifier (Repacked)

This package replaces hardcoded emails with **Script Properties**, adds robust **Cost** handling, and ships in a `clasp`-friendly structure.

## What’s inside
```
zucrow-se-purchase-notifier-repacked/
  .clasp.json           ← edit "scriptId"
  src/
    appsscript.json     ← manifest (minimal scopes)
    CONFIG.gs           ← reads Script Properties (NOTIFY_TO, CC_REQUESTER, etc.)
    UTIL.gs             ← helpers
    EMAIL.gs            ← email builder (includes Cost)
    Code.gs             ← onFormSubmit handler
```

## Quick start

1. **Create or bind an Apps Script project**
   - If your Sheet has no bound project: open the Sheet → Extensions → Apps Script (creates a bound project).
   - Or create a standalone Script and set `SHEET_ID` property (see below).

2. **Get the Script ID**
   - Apps Script editor → Project Settings → copy the **Script ID**.

3. **Edit `.clasp.json`**
   ```json
   {
     "scriptId": "REPLACE_WITH_YOUR_SCRIPT_ID",
     "rootDir": "src"
   }
   ```

4. **Install clasp & push**
   ```bash
   npm i -g @google/clasp
   clasp login
   clasp push
   ```

5. **Set Script Properties** (Apps Script → Project Settings → Script properties)
   - `NOTIFY_TO` – comma-separated emails (e.g., `lab-manager@purdue.edu, finance@purdue.edu`)
   - `CC_REQUESTER` – `true` or `false`
   - `SHEET_ID` – leave blank if the script is **bound** to your responses sheet; else paste Spreadsheet ID
   - `SHEET_NAME` – optional: target a specific tab (e.g., `Form Responses 1`)
   - `REQUESTER_EMAIL_HEADER` – header used for requester email if not auto-collected (default `Requester Email`)
   - `FORM_EMAIL_HEADER` – header for Google Form auto-collected email (default `Email Address`)

   > Tip: you can run `setupPropertiesDemo()` once from the editor to seed example values.

6. **Add trigger**
   - Apps Script editor → Triggers → **Add Trigger**
   - Choose function: `onFormSubmit`
   - Event source: **From spreadsheet**
   - Event type: **On form submit**

7. **Done**. New responses will send an email to `NOTIFY_TO`, and optionally CC the requester.

## Cost field
- The script looks for **`Cost`** (case-insensitive). It will also accept common variants: `Price`, `Amount`.
- It formats the value to USD if it can parse a number (e.g., `$1,234.50`). Otherwise it sends the raw text.

## Requester email logic
- If Forms auto-collects email, the header is often **`Email Address`** (configurable via `FORM_EMAIL_HEADER`).
- If not, supply a manual field like **`Requester Email`** and set `REQUESTER_EMAIL_HEADER` to match.

## Scopes
- `script.send_mail`, `script.properties`, `spreadsheets.readonly`

If you need Gmail API or Drive access later, add scopes in `appsscript.json` accordingly.
